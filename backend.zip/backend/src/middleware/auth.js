// Middleware to check if user is authenticated
// Attaches req.userId if valid session exists

function requireAuth(req, res, next) {
  if (!req.session || !req.session.userId) {
    return res.status(401).json({ error: 'Unauthorized. Please log in.' });
  }
  req.userId = req.session.userId;
  next();
}

module.exports = { requireAuth };
