const logger = require('../utils/logger');

// Central error handler - never exposes stack traces or internals to the client
function errorHandler(err, req, res, next) {
  // Log the real error server-side
  logger.error(`${err.message} | Route: ${req.method} ${req.path} | Stack: ${err.stack}`);

  // Prisma unique constraint violation (duplicate email)
  if (err.code === 'P2002') {
    return res.status(409).json({ error: 'An account with that email already exists.' });
  }

  // Prisma record not found
  if (err.code === 'P2025') {
    return res.status(404).json({ error: 'Resource not found.' });
  }

  // Generic fallback - do not expose internals
  const statusCode = err.status || 500;
  const message = statusCode === 500 ? 'Internal server error.' : err.message;

  res.status(statusCode).json({ error: message });
}

module.exports = { errorHandler };
