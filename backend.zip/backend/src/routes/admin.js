
const express = require('express');
const rateLimit = require('express-rate-limit');

const router = express.Router();

const requireAdmin = require('../middleware/requireAdmin');

const {
  getUsers,
  getNotes,
  createAccessRequest,
  decryptApprovedNote,
  emergencyDecryptNote,
} = require('../controllers/adminController');

// Limit emergency access attempts to 3 per 15 minutes per IP
const emergencyLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 3,
  message: {
    error: 'Too many emergency access attempts. Try again later.',
  },
  standardHeaders: true,
  legacyHeaders: false,
});

// Every admin route requires administrator authentication
router.use(requireAdmin);

// Administrator dashboard
router.get('/users', getUsers);
router.get('/notes', getNotes);

// Normal access: request permission from the note owner
router.post(
  '/notes/:id/access-request',
  createAccessRequest
);

// Decrypt only after owner approval
router.post(
  '/access-requests/:id/decrypt',
  decryptApprovedNote
);

// Emergency access: password verification and detailed justification
router.post(
  '/notes/:id/emergency-decrypt',
  emergencyLimiter,
  emergencyDecryptNote
);

module.exports = router;
