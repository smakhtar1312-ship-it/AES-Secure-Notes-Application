
const express = require('express');
const router = express.Router();

const {
  getNotes,
  getNoteById,
  createNote,
  updateNote,
  deleteNote
} = require('../controllers/notesController');

const {
  getMyAccessRequests,
  respondToAccessRequest,
  getEmergencyAccessNotifications
} = require('../controllers/accessRequestController');

const { requireAuth } = require('../middleware/auth');

const {
  createNoteValidation,
  updateNoteValidation,
  noteIdValidation
} = require('../validation/noteValidation');

// All note routes require authentication.
router.use(requireAuth);

// ========================================
// ACCESS REQUEST AND SECURITY NOTIFICATIONS
// ========================================

// Get normal administrator access requests.
router.get('/access-requests', getMyAccessRequests);

// Approve or deny a normal access request.
router.post('/access-requests/:id/respond', respondToAccessRequest);

// Get emergency access notifications for the logged-in user.
router.get('/security-notifications', getEmergencyAccessNotifications);

// ========================================
// PERSONAL NOTE ROUTES
// ========================================

router.get('/', getNotes);
router.get('/:id', noteIdValidation, getNoteById);
router.post('/', createNoteValidation, createNote);
router.put('/:id', updateNoteValidation, updateNote);
router.delete('/:id', noteIdValidation, deleteNote);

module.exports = router;
