// Load environment variables before any test runs
require('dotenv').config();
process.env.NODE_ENV = 'test';
